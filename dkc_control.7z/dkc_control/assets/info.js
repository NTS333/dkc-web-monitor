const info = {
    pw:"$2a$10$Ip6moasNxRPx/.Eoh0YwV.UJ/jqevzEYA7pl/8Vp2CW0XmKJwpmjy",
    usn: "$2a$10$Ip6moasNxRPx/.Eoh0YwV.UJ/jqevzEYA7pl/8Vp2CW0XmKJwpmjy" 
}